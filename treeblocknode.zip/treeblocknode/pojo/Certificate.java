package com.hhf.treeblocknode.pojo;

public class Certificate {
}
