package com.hhf.treeblocknode.pojo;

public class IotDevice {
}
