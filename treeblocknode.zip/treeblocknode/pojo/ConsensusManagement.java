package com.hhf.treeblocknode.pojo;

public  class ConsensusManagement {

    public  static void createConsensus(){

    }
}
