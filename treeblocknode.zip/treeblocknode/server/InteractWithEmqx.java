package com.hhf.treeblocknode.server;

import com.alibaba.fastjson2.JSON;
import com.hhf.treeblocknode.pojo.Subscriptions;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.Base64;

@Component
public class InteractWithEmqx {


}
