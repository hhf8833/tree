package com.hhf.treeblocknode.server.inter;

public interface DataAccService {
    void  blockAcc(String hash);
}
